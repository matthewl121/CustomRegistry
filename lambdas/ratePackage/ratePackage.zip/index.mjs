// import AWS from 'aws-sdk'; // Importing AWS SDK as an ES module
// const { SecretsManager } = AWS; // Extracting the SecretsManager class
// import { Client } from 'ssh2';  // Importing SSH2 module

// // Your EC2 Instance's Public IP Address and Secret Name
// const EC2_IP = '34.205.19.248'; // Replace with your EC2 public IP
// const secretName = 'MyEC2PrivateKey'; // Replace with your Secrets Manager secret name

// const secretsManager = new SecretsManager();

// const connectToEC2 = async () => {
//   try {
//     // Retrieve private key from Secrets Manager
//     const secretValue = await secretsManager.getSecretValue({ SecretId: secretName }).promise();
//     const privateKey = secretValue.SecretString;  // Retrieve the private key from the secret

//     // SSH client setup
//     const sshClient = new Client();
//     sshClient.on('ready', () => {
//       console.log('SSH connection established');
//       // Execute the 'uptime' command on the EC2 instance
//       sshClient.exec('uptime', (err, stream) => {
//         if (err) throw err;
//         stream.on('close', (code, signal) => {
//           console.log(`Stream closed with code: ${code}`);
//           sshClient.end();
//         }).on('data', (data) => {
//           console.log('STDOUT:', data.toString());
//         }).stderr.on('data', (data) => {
//           console.error('STDERR:', data.toString());
//         });
//       });
//     }).on('error', (err) => {
//       console.error('SSH connection failed', err);
//     }).connect({
//       host: EC2_IP,
//       port: 22,
//       username: 'ec2-user',  // Change if necessary
//       privateKey: privateKey  // Using private key from Secrets Manager
//     });
//   } catch (error) {
//     console.error('Error connecting to EC2:', error);
//   }
// };

// // Exporting the handler function
// export const handler = async (event, context) => {
//   await connectToEC2();
//   return {
//     statusCode: 200,
//     body: JSON.stringify({
//       message: 'SSH connection to EC2 established successfully.'
//     }),
//   };
// };

import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager'; // Import only the necessary components
import { Client } from 'ssh2'; // Import SSH2 module

// Your EC2 Instance's Public IP Address and Secret Name
const EC2_IP = '34.205.19.248'; // Replace with your EC2 public IP
const secretName = 'MyEC2PrivateKey'; // Replace with your Secrets Manager secret name

const secretsManager = new SecretsManagerClient({
  region: 'us-east-1', // Add the appropriate AWS region
});

const connectToEC2 = async () => {
  try {
    // Retrieve private key from Secrets Manager using SDK v3's new async method
    const command = new GetSecretValueCommand({ SecretId: secretName });
    const data = await secretsManager.send(command);

    const privateKey = data.SecretString; // Retrieve the private key from the secret

    // SSH client setup
    const sshClient = new Client();
    sshClient.on('ready', () => {
      console.log('SSH connection established');
      // Execute the 'uptime' command on the EC2 instance
      sshClient.exec('uptime', (err, stream) => {
        if (err) throw err;
        stream
          .on('close', (code, signal) => {
            console.log(`Stream closed with code: ${code}`);
            sshClient.end();
          })
          .on('data', (data) => {
            console.log('STDOUT:', data.toString());
          })
          .stderr.on('data', (data) => {
            console.error('STDERR:', data.toString());
          });
      });
    }).on('error', (err) => {
      console.error('SSH connection failed', err);
    }).connect({
      host: EC2_IP,
      port: 22,
      username: 'ec2-user', // Change if necessary
      privateKey: privateKey, // Using private key from Secrets Manager
    });
  } catch (error) {
    console.error('Error connecting to EC2:', error);
  }
};

// Exporting the handler function
export const handler = async (event, context) => {
  await connectToEC2();
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'SSH connection to EC2 established successfully.',
    }),
  };
};
