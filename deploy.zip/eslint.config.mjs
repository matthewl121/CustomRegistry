import config from "eslint-config-standard";


export default [
  {
    files: [
      "**/*.ts", // TypeScript files
      "**/*.js" // JavaScript files
    ]
  }  
];